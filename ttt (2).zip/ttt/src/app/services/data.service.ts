import { Injectable } from '@angular/core';
import { Observable, from } from 'rxjs';
import { HttpClient } from '@angular/common/http';

@Injectable()
export class DataService {

    constructor(private httpClient: HttpClient) {}

    getorderBySampleData(): Observable<any> {
        const url = 'assets/orderBySampleData.json';
        return this.httpClient.get(url);
    }

    higlightURLSampleData(): Observable<any> {
        const url = 'assets/higlightURLSampleData.json';
        return this.httpClient.get(url);
    }
}
