import { Component, OnInit } from '@angular/core';
import { DataService } from './services/data.service';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  title = 'my-app';
  constructor(private dataService: DataService) { }
  sampleData: any;
  highLightSampleData: any;
  ngOnInit() {

    // This is for Ordering task fetch from API and make it order wise
    this.dataService.getorderBySampleData().subscribe(res => {
      if (res) {
        console.log(res.data); // check the object format.... this.sampledata should have array of objects....that's it
        this.sampleData = res.data;
        this.sampleData.sort((a: any, b: any) => {
          if (a.Title < b.Title) {
            return -1;
          } else if (a.Title > b.Title) {
            return 1;
          } else {
            return 0;
          }
        });
      }
    });

    this.dataService.higlightURLSampleData().subscribe(res => {
      if (res) {
        console.log(res.data); // check the object format.... this.highLightSampleData should have array of objects....that's it
        this.highLightSampleData = res.data;
        this.highLightSampleData.map(d => {
          if (d.comments && d.comments.includes('https')) {
            d.comments = this.getContentWithHighlight(d.comments);
          }
        });
      }
    });


  }

  getContentWithHighlight(sentence) {
    const b = sentence.substring(sentence.indexOf('https:'), sentence.length);
    let c = '';
    for (let i = 0; i < b.length; i++) {
      if (b.charAt(i) === ' ' || (b.charAt(i) === ',')) {
        break;
      } else {
        c = c + b.charAt(i);
      }
    }
    const firstHalf = sentence.substring(0, sentence.indexOf(c));
    const secondHalf = sentence.substring(sentence.indexOf(c) + c.length, sentence.length);
    const finalSentence = firstHalf + '<a href = "' + c + '" >' + c + '</a>' + secondHalf;
    return finalSentence;
  }
}
